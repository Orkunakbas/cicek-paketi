// store/index.js veya store.js
import { configureStore } from "@reduxjs/toolkit"





export const store = configureStore({
  reducer: {

 
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false
    })
})



export default store
