export const locales = ['tr', 'en'];
export const defaultLocale = 'tr';

export default function getRequestConfig() {
  return {
    locales: ['tr', 'en'],
    defaultLocale: 'tr'
  };
} 