// örneğin: app/data/ort.js
export const orts = [
    {
      label: "Zürich",
      key: "Zürich",
    },
    {
      label: "Bern",
      key: "Bern",
    },
    {
      label: "Genève (Cenevre)",
      key: "Genève (Cenevre)",
    },
    {
      label: "Basel",
      key: "Basel",
    },
    {
      label: "Luzern",
      key: "Luzern",
    },
    {
      label: "Lugano",
      key: "Lugano",
    },
  ];
  