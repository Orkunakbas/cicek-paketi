export const salesRepNotes = [
    {
      name: "Ali",
      surname: "Demir",
      date: "2024-01-12 09:15",
      note: "Müşteriyle ilk görüşme yapıldı, fiyat teklifi hazırlanıyor."
    },
    {
      name: "Ayşe",
      surname: "Şahin",
      date: "2024-01-13 10:30",
      note: "E-posta üzerinden ek doküman istedi, yarın göndereceğim."
    },
    {
      name: "Berk",
      surname: "Kaya",
      date: "2024-01-15 14:20",
      note: "Telefonla görüşme yapıldı, ödeme koşulları tartışıldı."
    },
    {
      name: "Cem",
      surname: "Arslan",
      date: "2024-01-16 11:45",
      note: "Müşteri memnuniyeti anketi dolduruldu, olumsuz bir görüş yok."
    },
    {
      name: "Deniz",
      surname: "Öztürk",
      date: "2024-01-17 16:10",
      note: "İndirim talep etti, üst yönetimden onay bekliyorum."
    },
    {
      name: "Elif",
      surname: "Yılmaz",
      date: "2024-01-18 09:05",
      note: "Detaylı teknik doküman gönderdim, geri dönüş bekleniyor."
    },
    {
      name: "Fatih",
      surname: "Çelik",
      date: "2024-01-19 13:30",
      note: "Müşteri, rakip firmanın fiyatlarını sordu. Analiz edilecek."
    },
    {
      name: "Gizem",
      surname: "Baş",
      date: "2024-01-20 15:00",
      note: "Online demo talebi iletildi, teknik ekiple zaman planlanıyor."
    },
    {
      name: "Hakan",
      surname: "Yıldız",
      date: "2024-01-21 10:25",
      note: "Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik. Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik. Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik.Teklif güncellemesi yaptık, yeni fiyatı onay için gönderdik."
    },
    {
      name: "Işıl",
      surname: "Kara",
      date: "2024-01-22 16:55",
      note: "Müşteriyle Zoom görüşmesi yapıldı, sözleşme taslağı paylaşıldı."
    },
    {
      name: "Kemal",
      surname: "Aydın",
      date: "2024-01-23 09:00",
      note: "Teknik servis yönlendirildi, kurulum bekleniyor."
    },
    {
      name: "Leyla",
      surname: "Bal",
      date: "2024-01-23 14:45",
      note: "Ödeme planı tekrar görüşülecek. Müşteri kısmi ödeme önerdi."
    },
    {
      name: "Mert",
      surname: "Uslu",
      date: "2024-01-24 11:20",
      note: "Takip araması yapıldı, henüz karar vermediklerini belirtti."
    },
    {
      name: "Nazan",
      surname: "Polat",
      date: "2024-01-25 10:10",
      note: "Fuar daveti gönderildi, katılım sağlayacaklarını iletti."
    },
    {
      name: "Ozan",
      surname: "Akın",
      date: "2024-01-26 17:00",
      note: "Çapraz satış fırsatı konuşuldu, ek ürünlere ilgi gösterdi."
    }
  ];
  